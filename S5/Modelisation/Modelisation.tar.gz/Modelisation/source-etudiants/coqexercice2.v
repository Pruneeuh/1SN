Require Import Naturelle.
Section Session1_2019_Logique_Exercice_2.

Variable A B : Prop.

Theorem Exercice_2_Coq : (~A) \/ B -> (~A) \/ (A /\ B).
Proof.
intro.
right.
cut A.
intro.
split.
Hyp H0.


elim H.
intro.

split.
Qed.

Theorem Exercice_2_Naturelle : (~A) \/ B -> (~A) \/ (A /\ B).
Proof.
I_imp H.
I_ou_d.
I_et.
E_ou(~A)(B).
Hyp H.
I_imp H2.
Qed.

End Session1_2019_Logique_Exercice_2.

